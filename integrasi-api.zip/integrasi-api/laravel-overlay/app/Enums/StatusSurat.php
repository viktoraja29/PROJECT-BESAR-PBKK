<?php

namespace App\Enums;

enum StatusSurat: string
{
    case Diajukan = 'diajukan';
    case Diproses = 'diproses';
    case Selesai = 'selesai';
    case Ditolak = 'ditolak';

    public function label(): string
    {
        return match ($this) {
            self::Diajukan => 'Diajukan',
            self::Diproses => 'Diproses',
            self::Selesai => 'Selesai',
            self::Ditolak => 'Ditolak',
        };
    }

    // teks tombol untuk menuju status ini
    public function labelAksi(): string
    {
        return match ($this) {
            self::Diajukan => 'Ajukan',
            self::Diproses => 'Proses',
            self::Selesai => 'Selesaikan',
            self::Ditolak => 'Tolak',
        };
    }

    /** @return list<StatusSurat> */
    public function berikutnya(): array
    {
        return match ($this) {
            self::Diajukan => [self::Diproses, self::Ditolak],
            self::Diproses => [self::Selesai, self::Ditolak],
            self::Selesai, self::Ditolak => [],
        };
    }

    public function bisaBerubahKe(self $baru): bool
    {
        return in_array($baru, $this->berikutnya(), true);
    }
}
