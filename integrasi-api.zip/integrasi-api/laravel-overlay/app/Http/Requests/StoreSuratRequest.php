<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class StoreSuratRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true; // pengajuan terbuka untuk mahasiswa (publik), dibatasi throttle di route
    }

    public function rules(): array
    {
        // Cara input modul ORM: mahasiswa_id + jenis_surat_id (id yang sudah ada di database)
        if ($this->has('mahasiswa_id') || $this->has('jenis_surat_id')) {
            return [
                'mahasiswa_id' => ['required', 'integer', 'exists:mahasiswa,id'],
                'jenis_surat_id' => ['required', 'integer', 'exists:jenis_surat,id'],
                'keperluan' => ['required', 'string', 'min:10'],
            ];
        }

        // Cara input frontend: nama + NIM + nama jenis surat
        return [
            'nama' => ['required', 'string', 'max:100'],
            'nim' => ['required', 'regex:/^\d{5,15}$/'],
            // exists: dicek ke tabel jenis_surat di database, bukan ke daftar tetap di kode
            'jenis' => ['required', Rule::exists('jenis_surat', 'nama')],
            'keperluan' => ['required', 'string', 'min:10'],
        ];
    }

    public function messages(): array
    {
        return [
            'mahasiswa_id.exists' => 'Mahasiswa tidak ditemukan.',
            'jenis_surat_id.exists' => 'Jenis surat tidak ditemukan.',
            'nama.required' => 'Nama wajib diisi.',
            'nama.string' => 'Nama harus berupa teks.',
            'nama.max' => 'Nama maksimal 100 karakter.',
            'nim.required' => 'NIM harus berupa angka (5-15 digit).',
            'nim.regex' => 'NIM harus berupa angka (5-15 digit).',
            'jenis.required' => 'Pilih jenis surat.',
            'jenis.exists' => 'Pilih jenis surat.',
            'keperluan.required' => 'Keperluan minimal 10 karakter.',
            'keperluan.string' => 'Keperluan minimal 10 karakter.',
            'keperluan.min' => 'Keperluan minimal 10 karakter.',
        ];
    }
}
