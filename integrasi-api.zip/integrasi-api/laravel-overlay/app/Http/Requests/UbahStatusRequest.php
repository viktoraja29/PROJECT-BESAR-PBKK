<?php

namespace App\Http\Requests;

use App\Enums\StatusSurat;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class UbahStatusRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'status' => ['required', Rule::enum(StatusSurat::class)],
            'catatan' => ['nullable', 'string', 'max:255'],
            'dosen_id' => ['nullable', 'integer', 'exists:dosen,id'], // dosen penyetujui (latihan 3)
        ];
    }

    public function messages(): array
    {
        return [
            'status.required' => 'Status wajib diisi.',
            'status.enum' => 'Status tidak valid.',
            'catatan.string' => 'Catatan harus berupa teks maksimal 255 karakter.',
            'catatan.max' => 'Catatan harus berupa teks maksimal 255 karakter.',
        ];
    }
}
