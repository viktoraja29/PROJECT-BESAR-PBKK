<?php

namespace App\Http\Controllers\Api;

use App\Enums\StatusSurat;
use App\Http\Controllers\Controller;
use App\Http\Requests\StoreSuratRequest;
use App\Http\Requests\UbahStatusRequest;
use App\Http\Resources\SuratResource;
use App\Models\JenisSurat;
use App\Models\Mahasiswa;
use App\Models\Surat;
use App\Services\NotifikasiService;
use DomainException;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rule;
use Illuminate\Validation\ValidationException;

class SuratController extends Controller
{
    // GET /api/v1/surat?status=diajukan&q=viktor&page=2&per_page=5
    public function index(Request $request)
    {
        $request->validate(
            ['status' => ['nullable', Rule::enum(StatusSurat::class)]],
            ['status.enum' => 'Status tidak valid.'],
        );

        $perPage = min(50, max(1, $request->integer('per_page', 10)));

        $surat = Surat::query()
            ->with(['mahasiswa:id,nim,nama', 'jenisSurat:id,nama'])   // eager loading: 3 query, bukan N+1
            ->when($request->query('status'), fn ($q, $s) => $q->status(StatusSurat::from($s)))
            ->when($request->string('q')->trim()->toString(), fn ($q, $kata) => $q->cari($kata))
            ->latest('id')
            ->paginate($perPage)
            ->withQueryString();

        return SuratResource::collection($surat); // { data, links, meta }
    }

    // POST /api/v1/surat
    public function store(StoreSuratRequest $request)
    {
        $data = $request->validated();

        // Satu transaksi: mahasiswa (jika belum ada) + surat + riwayat pertama
        $surat = DB::transaction(function () use ($data) {
            // Cara 1 (modul ORM): langsung memakai id mahasiswa dan id jenis surat
            if (isset($data['mahasiswa_id'])) {
                return Surat::ajukan([
                    'mahasiswa_id' => $data['mahasiswa_id'],
                    'jenis_surat_id' => $data['jenis_surat_id'],
                    'keperluan' => $data['keperluan'],
                ]);
            }

            // Cara 2 (frontend): nama, NIM, nama jenis.
            // NIM sudah terdaftar -> pakai mahasiswa yang ada; belum -> dibuat baru
            $mahasiswa = Mahasiswa::firstOrCreate(
                ['nim' => $data['nim']],
                ['nama' => $data['nama']],
            );

            return Surat::ajukan([
                'mahasiswa_id' => $mahasiswa->id,
                'jenis_surat_id' => JenisSurat::where('nama', $data['jenis'])->firstOrFail()->id,
                'keperluan' => $data['keperluan'],
            ]);
        });

        return (new SuratResource($surat->load('mahasiswa', 'jenisSurat', 'disetujuiOleh', 'riwayat')))
            ->response()
            ->setStatusCode(201);
    }

    // GET /api/v1/surat/{surat} -> 404 otomatis jika tidak ada
    public function show(Surat $surat)
    {
        return new SuratResource($surat->load('mahasiswa', 'jenisSurat', 'disetujuiOleh', 'riwayat'));
    }

    // PATCH /api/v1/surat/{surat}/status
    public function ubahStatus(UbahStatusRequest $request, Surat $surat, NotifikasiService $notifikasi)
    {
        try {
            $surat->ubahStatus(
                StatusSurat::from($request->input('status')),
                $request->input('catatan'),
                $request->integer('dosen_id') ?: null,   // dosen penyetujui (latihan 3)
            );
        } catch (DomainException $e) {
            // aturan bisnis gagal -> format 422 yang sama dengan error validasi
            throw ValidationException::withMessages(['status' => $e->getMessage()]);
        }

        $surat->load('mahasiswa', 'jenisSurat', 'disetujuiOleh', 'riwayat');
        $notifikasi->statusBerubah($surat); // integrasi: webhook ke Node.js

        return new SuratResource($surat); // 200
    }

    // DELETE /api/v1/surat/{surat} -> soft delete: hanya mengisi deleted_at, datanya masih ada
    public function destroy(Surat $surat)
    {
        $surat->delete();

        return response()->noContent(); // 204
    }

    // GET /api/v1/surat-terhapus -> daftar surat yang di-soft delete (latihan 4)
    public function terhapus()
    {
        $surat = Surat::onlyTrashed()
            ->with(['mahasiswa:id,nim,nama', 'jenisSurat:id,nama'])
            ->latest('deleted_at')
            ->get();

        return SuratResource::collection($surat);
    }

    // POST /api/v1/surat/{id}/pulihkan -> mengembalikan surat yang terhapus (latihan 4)
    public function pulihkan(int $id)
    {
        // route model binding bawaan tidak menemukan surat terhapus, jadi dicari manual
        $surat = Surat::onlyTrashed()->findOrFail($id);
        $surat->restore();

        return new SuratResource($surat->load('mahasiswa', 'jenisSurat', 'disetujuiOleh', 'riwayat'));
    }

    // GET /api/v1/statistik (Tugas 3)
    public function statistik()
    {
        // toBase(): hasilnya baris biasa. Jika tetap model, kolom status diubah ke enum
        // dan enum tidak bisa dipakai sebagai kunci array pada pluck().
        $hitung = Surat::query()
            ->toBase()
            ->selectRaw('status, count(*) as total')
            ->groupBy('status')
            ->pluck('total', 'status');

        $data = ['semua' => (int) $hitung->sum()];
        foreach (StatusSurat::cases() as $status) {
            $data[$status->value] = (int) ($hitung[$status->value] ?? 0);
        }

        // latihan 2: jumlah surat per jenis surat (withCount = satu query, bukan N+1)
        $data['per_jenis'] = JenisSurat::withCount('surat')->orderBy('id')->get()
            ->map(fn (JenisSurat $j) => ['jenis' => $j->nama, 'jumlah' => $j->surat_count])
            ->all();

        return response()->json(['data' => $data]);
    }
}
