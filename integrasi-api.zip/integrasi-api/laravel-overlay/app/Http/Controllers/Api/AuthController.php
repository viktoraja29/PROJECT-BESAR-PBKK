<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\ValidationException;

class AuthController extends Controller
{
    // POST /api/v1/login -> { data: { token, token_type, user } }
    public function login(Request $request)
    {
        $data = $request->validate([
            'email' => ['required', 'email'],
            'password' => ['required', 'string'],
        ], [
            'email.required' => 'Email wajib diisi.',
            'email.email' => 'Email tidak valid.',
            'password.required' => 'Password wajib diisi.',
            'password.string' => 'Password wajib diisi.',
        ]);

        $user = User::where('email', $data['email'])->first();

        if (! $user || ! Hash::check($data['password'], $user->password)) {
            // format 422 yang sama dengan error validasi
            throw ValidationException::withMessages([
                'email' => 'Email atau password salah.',
            ]);
        }

        // token berlaku 2 jam
        $token = $user->createToken('frontend', ['*'], now()->addHours(2))->plainTextToken;

        return response()->json(['data' => [
            'token' => $token,
            'token_type' => 'Bearer',
            'user' => $this->userData($user),
        ]]);
    }

    // GET /api/v1/me
    public function me(Request $request)
    {
        return response()->json(['data' => $this->userData($request->user())]);
    }

    // POST /api/v1/logout -> 204 (token yang dipakai dicabut)
    public function logout(Request $request)
    {
        $request->user()->currentAccessToken()->delete();

        return response()->noContent();
    }

    // bentuk user sama dengan versi Node.js: { id, nama, email }
    private function userData(User $user): array
    {
        return ['id' => $user->id, 'nama' => $user->name, 'email' => $user->email];
    }
}
