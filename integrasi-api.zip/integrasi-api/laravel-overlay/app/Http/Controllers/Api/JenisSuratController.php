<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\JenisSurat;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

/**
 * Latihan 1: CRUD Jenis Surat memakai ORM.
 * Menghapus jenis surat yang masih dipakai -> 409 Conflict (bukan error 500 dari foreign key).
 */
class JenisSuratController extends Controller
{
    /** GET /api/v1/jenis-surat (publik; dipakai dropdown frontend) */
    public function index()
    {
        return ['data' => JenisSurat::withCount('surat')->orderBy('id')->get()];
    }

    /** POST /api/v1/jenis-surat */
    public function store(Request $request)
    {
        $data = $request->validate([
            'kode' => ['required', 'string', 'max:10', 'unique:jenis_surat,kode'],
            'nama' => ['required', 'string', 'max:100', 'unique:jenis_surat,nama'],
        ]);

        return response()->json(['data' => JenisSurat::create($data)], 201);
    }

    /** GET /api/v1/jenis-surat/{jenis_surat} */
    public function show(JenisSurat $jenisSurat)
    {
        return ['data' => $jenisSurat->loadCount('surat')];
    }

    /** PUT/PATCH /api/v1/jenis-surat/{jenis_surat} */
    public function update(Request $request, JenisSurat $jenisSurat)
    {
        $data = $request->validate([
            'kode' => ['sometimes', 'string', 'max:10', Rule::unique('jenis_surat', 'kode')->ignore($jenisSurat->id)],
            'nama' => ['sometimes', 'string', 'max:100', Rule::unique('jenis_surat', 'nama')->ignore($jenisSurat->id)],
        ]);

        $jenisSurat->update($data);

        return ['data' => $jenisSurat];
    }

    /** DELETE /api/v1/jenis-surat/{jenis_surat} */
    public function destroy(JenisSurat $jenisSurat)
    {
        // Dicek lebih dulu: tanpa ini database menolak (restrictOnDelete) dan hasilnya error 500.
        if ($jenisSurat->surat()->exists()) {
            return response()->json([
                'message' => "Jenis surat \"{$jenisSurat->nama}\" masih dipakai oleh surat dan tidak bisa dihapus.",
            ], 409);
        }

        $jenisSurat->delete();

        return response()->noContent();
    }
}
