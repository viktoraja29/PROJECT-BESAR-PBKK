<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class ApiKey
{
    public function handle(Request $request, Closure $next): Response
    {
        $seharusnya = (string) config('services.api_key');
        $dikirim = (string) $request->header('X-API-Key');

        // kunci kosong selalu ditolak (hash_equals('', '') bernilai true)
        if ($seharusnya === '' || $dikirim === '' || ! hash_equals($seharusnya, $dikirim)) {
            return response()->json(['message' => 'API key tidak valid.'], 401);
        }

        return $next($request);
    }
}
