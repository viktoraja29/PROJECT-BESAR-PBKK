<?php

namespace App\Http\Resources;

use App\Enums\StatusSurat;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

/**
 * Bentuk JSON-nya SAMA dengan versi Node.js, walau data kini tersebar di beberapa tabel:
 * nama dan nim dari relasi mahasiswa, jenis dari relasi jenisSurat, riwayat dari tabel riwayat_status.
 * Relasi harus sudah dimuat oleh controller (with / load) agar tidak terjadi N+1.
 *
 * @mixin \App\Models\Surat
 */
class SuratResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'nomor' => $this->nomor,
            'nama' => $this->mahasiswa->nama,
            'nim' => $this->mahasiswa->nim,
            'jenis' => $this->jenisSurat->nama,
            'keperluan' => $this->keperluan,
            'status' => $this->status->value,
            'status_label' => $this->status->label(),
            'aksi_berikutnya' => array_map(
                fn (StatusSurat $s) => ['status' => $s->value, 'label' => $s->labelAksi()],
                $this->status->berikutnya(),
            ),
            // hanya ada jika relasinya dimuat (detail), tidak di daftar
            // latihan 3: nama dosen penyetujui, hanya jika relasinya dimuat (detail)
            'disetujui_oleh' => $this->whenLoaded('disetujuiOleh', fn () => $this->disetujuiOleh?->nama),
            'riwayat' => $this->whenLoaded('riwayat', fn () => $this->riwayat->map(fn ($r) => [
                'status' => $r->status->value,
                'waktu' => $r->created_at->toIso8601String(),
                'catatan' => $r->catatan,
            ])),
            'dibuat_pada' => $this->created_at?->toIso8601String(),
        ];
    }
}
