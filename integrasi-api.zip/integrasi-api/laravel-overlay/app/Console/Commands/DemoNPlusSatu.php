<?php

namespace App\Console\Commands;

use App\Models\Surat;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;

/**
 * Membuktikan masalah N+1: jumlah query lazy loading vs eager loading.
 * Pemakaian: php artisan demo:n-plus-1   (lebih jelas setelah: php artisan db:seed --class=DataPalsuSeeder)
 */
class DemoNPlusSatu extends Command
{
    protected $signature = 'demo:n-plus-1';

    protected $description = 'Membandingkan jumlah query: lazy loading (N+1) vs eager loading (with)';

    public function handle(): int
    {
        $jumlah = Surat::count();

        $lazy = $this->hitungQuery(function () {
            foreach (Surat::all() as $surat) {
                $surat->mahasiswa->nama;     // query baru untuk SETIAP surat
            }
        });

        $eager = $this->hitungQuery(function () {
            foreach (Surat::with('mahasiswa')->get() as $surat) {
                $surat->mahasiswa->nama;     // sudah dimuat, tanpa query baru
            }
        });

        $this->table(
            ['Cara', 'Jumlah query'],
            [['Lazy loading: Surat::all()', $lazy], ['Eager loading: Surat::with(\'mahasiswa\')', $eager]],
        );
        $this->line("Jumlah surat: {$jumlah}. Lazy = 1 + N query, eager = selalu 2 query.");

        return self::SUCCESS;
    }

    private function hitungQuery(callable $kerja): int
    {
        DB::flushQueryLog();
        DB::enableQueryLog();
        $kerja();
        $total = count(DB::getQueryLog());
        DB::disableQueryLog();

        return $total;
    }
}
