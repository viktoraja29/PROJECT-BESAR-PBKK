<?php

namespace App\Models;

use App\Enums\StatusSurat;
use DomainException;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Support\Facades\DB;

class Surat extends Model
{
    use SoftDeletes; // delete() hanya mengisi deleted_at; baris tetap ada di tabel

    protected $table = 'surat';

    // nomor & status TIDAK ada di sini: diatur oleh sistem, bukan input user
    protected $fillable = ['mahasiswa_id', 'jenis_surat_id', 'keperluan'];

    protected $attributes = ['status' => 'diajukan'];

    protected function casts(): array
    {
        return ['status' => StatusSurat::class]; // string di DB <-> enum di PHP
    }

    // ---------------- RELASI ----------------

    /** Surat MILIK satu mahasiswa (many-to-one). FK: surat.mahasiswa_id */
    public function mahasiswa(): BelongsTo
    {
        return $this->belongsTo(Mahasiswa::class);
    }

    /** FK: surat.jenis_surat_id (ditebak dari nama method jenisSurat) */
    public function jenisSurat(): BelongsTo
    {
        return $this->belongsTo(JenisSurat::class);
    }

    /** Dosen yang menyetujui (boleh kosong). FK: surat.disetujui_oleh, nama method ≠ nama kolom sehingga FK ditulis eksplisit */
    public function disetujuiOleh(): BelongsTo
    {
        return $this->belongsTo(Dosen::class, 'disetujui_oleh');
    }

    /** Satu surat punya banyak riwayat status. FK: riwayat_status.surat_id */
    public function riwayat(): HasMany
    {
        return $this->hasMany(RiwayatStatus::class)->orderBy('id');
    }

    // ---------------- QUERY SCOPE ----------------

    /** Pemakaian: Surat::status(StatusSurat::Diproses)->get() */
    public function scopeStatus(Builder $query, StatusSurat $status): void
    {
        $query->where('status', $status->value);
    }

    /** Cari berdasarkan nama atau NIM mahasiswa pemilik surat. Pemakaian: Surat::cari('viktor')->get() */
    public function scopeCari(Builder $query, string $kata): void
    {
        $query->whereHas('mahasiswa', fn (Builder $m) => $m->where(fn (Builder $w) => $w
            ->where('nama', 'like', "%{$kata}%")
            ->orWhere('nim', 'like', "%{$kata}%")));
    }

    // ---------------- ATURAN BISNIS ----------------

    /**
     * Membuat surat + riwayat pertama dalam SATU TRANSAKSI:
     * jika salah satu gagal, semuanya dibatalkan (rollback).
     */
    public static function ajukan(array $data): self
    {
        return DB::transaction(function () use ($data) {
            $surat = self::create($data);                         // INSERT surat

            // nomor butuh id, jadi diisi setelah INSERT
            $surat->nomor = sprintf('SRT/%04d/%s', $surat->id, now()->year);
            $surat->save();                                       // UPDATE nomor

            $surat->riwayat()->create([                           // INSERT riwayat
                'status'  => StatusSurat::Diajukan,
                'catatan' => 'Pengajuan dibuat oleh mahasiswa.',
            ]);

            return $surat;
        });
    }

    public function ubahStatus(StatusSurat $baru, ?string $catatan = null, ?int $dosenId = null): void
    {
        if (! $this->status->bisaBerubahKe($baru)) {
            throw new DomainException(
                "Status {$this->status->label()} tidak bisa diubah ke {$baru->label()}."
            );
        }

        $catatan = trim((string) $catatan);

        DB::transaction(function () use ($baru, $catatan, $dosenId) {
            $this->status = $baru;
            if ($dosenId !== null) {
                $this->disetujui_oleh = $dosenId;                 // dosen penyetujui
            }
            $this->save();                                        // UPDATE status

            $this->riwayat()->create([                            // INSERT riwayat
                'status'  => $baru,
                'catatan' => $catatan !== '' ? $catatan : "Status diubah menjadi {$baru->label()}.",
            ]);
        });
    }
}
