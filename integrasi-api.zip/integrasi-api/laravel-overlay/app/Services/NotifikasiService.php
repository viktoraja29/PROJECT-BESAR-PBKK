<?php

namespace App\Services;

use App\Models\Surat;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

/**
 * Webhook: memberi tahu layanan notifikasi (Node.js) saat status surat berubah.
 * Gagal kirim notifikasi TIDAK boleh menggagalkan proses utama.
 */
class NotifikasiService
{
    public function statusBerubah(Surat $surat): void
    {
        $surat->loadMissing('mahasiswa'); // nama dan nim ada di tabel mahasiswa

        try {
            $response = Http::withHeaders(['X-API-Key' => (string) config('services.notifikasi.key')])
                ->acceptJson()
                ->timeout(5)      // jangan tunggu lama
                ->retry(2, 200)   // coba ulang 2x
                ->post((string) config('services.notifikasi.url'), [
                    'event' => 'surat.status_berubah',
                    'data' => [
                        'nomor' => $surat->nomor,
                        'nama' => $surat->mahasiswa->nama,
                        'nim' => $surat->mahasiswa->nim,
                        'status' => $surat->status->value,
                        'status_label' => $surat->status->label(),
                    ],
                    'terjadi_pada' => now()->toIso8601String(),
                ]);

            if ($response->failed()) {
                Log::warning('Webhook ditolak: HTTP '.$response->status());
            }
        } catch (\Throwable $e) {
            Log::warning('Webhook gagal: '.$e->getMessage());
        }
    }
}
