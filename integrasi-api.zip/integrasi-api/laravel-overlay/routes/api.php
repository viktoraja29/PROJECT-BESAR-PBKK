<?php

use App\Http\Controllers\Api\AuthController;
use App\Http\Controllers\Api\JenisSuratController;
use App\Http\Controllers\Api\MahasiswaController;
use App\Http\Controllers\Api\SuratController;
use App\Models\Dosen;
use Illuminate\Support\Facades\Route;

Route::prefix('v1')->group(function () {
    // Login: maks 10 percobaan per menit
    Route::post('login', [AuthController::class, 'login'])->middleware('throttle:10,1');

    // Jenis surat: baca terbuka (dropdown frontend), tulis khusus admin (di grup bawah)
    Route::apiResource('jenis-surat', JenisSuratController::class)->only(['index', 'show']);

    // Tugas 3: statistik jumlah surat per status
    Route::get('statistik', [SuratController::class, 'statistik']);

    // Baca: terbuka (index dan show saja dari apiResource)
    Route::apiResource('surat', SuratController::class)->only(['index', 'show']);

    // Mahasiswa (publik) boleh mengajukan surat tanpa login; dibatasi 30 request per menit
    Route::post('surat', [SuratController::class, 'store'])->middleware('throttle:30,1');

    // Admin: wajib token Bearer (Laravel Sanctum)
    Route::middleware('auth:sanctum')->group(function () {
        Route::get('me', [AuthController::class, 'me']);
        Route::post('logout', [AuthController::class, 'logout']);

        Route::patch('surat/{surat}/status', [SuratController::class, 'ubahStatus']);
        Route::delete('surat/{surat}', [SuratController::class, 'destroy']);

        // Latihan 1: tulis jenis surat (hapus yang masih dipakai -> 409)
        Route::apiResource('jenis-surat', JenisSuratController::class)->only(['store', 'update', 'destroy']);

        // Latihan 3: daftar dosen untuk memilih penyetujui
        Route::get('dosen', fn () => ['data' => Dosen::orderBy('nama')->get()]);

        // Latihan 4 (soft delete): lihat surat terhapus dan pulihkan
        Route::get('surat-terhapus', [SuratController::class, 'terhapus']);
        Route::post('surat/{id}/pulihkan', [SuratController::class, 'pulihkan'])->whereNumber('id');

        // CRUD mahasiswa (khusus Laravel): 5 route sekaligus: index, store, show, update, destroy
        Route::apiResource('mahasiswa', MahasiswaController::class);
    });
});
