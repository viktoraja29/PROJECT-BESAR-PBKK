<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Migration BARU yang mengubah tabel yang sudah ada (bukan mengedit migration lama).
 * Dosen yang menyetujui surat: boleh kosong, dan jika dosennya dihapus nilainya menjadi NULL.
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::table('surat', function (Blueprint $table) {
            $table->foreignId('disetujui_oleh')
                  ->nullable()
                  ->after('status')
                  ->constrained('dosen')
                  ->nullOnDelete();
        });
    }

    public function down(): void
    {
        Schema::table('surat', function (Blueprint $table) {
            $table->dropConstrainedForeignId('disetujui_oleh');
        });
    }
};
