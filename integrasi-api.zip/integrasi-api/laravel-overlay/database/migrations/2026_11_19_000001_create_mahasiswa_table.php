<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('mahasiswa', function (Blueprint $table) {
            $table->id();                              // BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY
            $table->string('nim', 15)->unique();       // NIM = string, bukan angka (bisa diawali 0)
            $table->string('nama', 100);

            // Boleh kosong: mahasiswa yang mengajukan surat lewat form publik hanya mengisi nama dan NIM.
            // Prodi dan angkatan dilengkapi admin lewat CRUD /mahasiswa.
            $table->string('prodi', 50)->nullable();
            $table->unsignedSmallInteger('angkatan')->nullable();

            $table->timestamps();                      // created_at, updated_at
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('mahasiswa');
    }
};
