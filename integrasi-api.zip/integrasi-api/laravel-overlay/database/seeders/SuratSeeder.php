<?php

namespace Database\Seeders;

use App\Enums\StatusSurat;
use App\Models\Dosen;
use App\Models\JenisSurat;
use App\Models\Mahasiswa;
use App\Models\Surat;
use Illuminate\Database\Seeder;

class SuratSeeder extends Seeder
{
    /**
     * Data contoh yang mudah dikenali (sama dengan versi Node.js).
     * Mahasiswa dibuat sekali, surat memakai foreign key-nya, riwayat dibuat otomatis
     * oleh Surat::ajukan() dan Surat::ubahStatus().
     */
    public function run(): void
    {
        $farhan = $this->mahasiswa('2443027', 'Muhammad Farhan');
        $s1 = $this->ajukan($farhan, 'SKAK', 'Persyaratan administrasi beasiswa tahun ajaran 2026/2027.');
        $s1->ubahStatus(StatusSurat::Diproses, 'Sedang diverifikasi bagian akademik.');
        $s1->ubahStatus(StatusSurat::Selesai, 'Surat sudah dapat diambil.', Dosen::first()?->id);

        $syahreza = $this->mahasiswa('2443039', 'Muhammad Syahreza');
        $s2 = $this->ajukan($syahreza, 'PKL', 'Magang semester 7 di perusahaan teknologi di Samarinda.');
        $s2->ubahStatus(StatusSurat::Diproses, 'Menunggu tanda tangan ketua program studi.');

        $shanjay = $this->mahasiswa('2443014', 'Shanjay Wijaya Indra Kirana');
        $s3 = $this->ajukan($shanjay, 'SIP', 'Penelitian skripsi tentang pertanian di desa binaan.');
        $s3->ubahStatus(StatusSurat::Ditolak, 'Proposal belum disetujui pembimbing.');

        $viktor = $this->mahasiswa('2443085', 'Viktor');
        $this->ajukan($viktor, 'SRB', 'Pendaftaran beasiswa prestasi tingkat provinsi.');

        $julivian = $this->mahasiswa('2443028', 'Julivian Dodi');
        $s5 = $this->ajukan($julivian, 'SKL', 'Persyaratan pendaftaran wisuda periode berikutnya.');
        $s5->ubahStatus(StatusSurat::Diproses, 'Sedang diperiksa bagian akademik.');
    }

    private function mahasiswa(string $nim, string $nama): Mahasiswa
    {
        // Prodi dan angkatan hanya data contoh; ubah sesuai kenyataan jika perlu.
        return Mahasiswa::create([
            'nim' => $nim, 'nama' => $nama,
            'prodi' => 'Teknik Informatika', 'angkatan' => 2024,
        ]);
    }

    private function ajukan(Mahasiswa $mahasiswa, string $kodeJenis, string $keperluan): Surat
    {
        return Surat::ajukan([
            'mahasiswa_id'   => $mahasiswa->id,
            'jenis_surat_id' => JenisSurat::where('kode', $kodeJenis)->value('id'),
            'keperluan'      => $keperluan,
        ]);
    }
}
