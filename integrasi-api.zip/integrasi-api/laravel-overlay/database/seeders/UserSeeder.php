<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Seeder;

class UserSeeder extends Seeder
{
    public function run(): void
    {
        // akun demo (sama dengan versi Node.js): admin@kampus.test / password
        User::firstOrCreate(
            ['email' => 'admin@kampus.test'],
            ['name' => 'Admin Akademik', 'password' => 'password'],
        );
    }
}
