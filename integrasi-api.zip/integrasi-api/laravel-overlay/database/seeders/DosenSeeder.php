<?php

namespace Database\Seeders;

use App\Models\Dosen;
use Illuminate\Database\Seeder;

class DosenSeeder extends Seeder
{
    /** NIDN dan nama hanya contoh. */
    public function run(): void
    {
        Dosen::create(['nidn' => '0011223301', 'nama' => 'Dr. Contoh Pertama, M.Kom.']);
        Dosen::create(['nidn' => '0011223302', 'nama' => 'Contoh Kedua, M.T.']);
    }
}
