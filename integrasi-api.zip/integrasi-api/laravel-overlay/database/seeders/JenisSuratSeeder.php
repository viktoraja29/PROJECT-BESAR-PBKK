<?php

namespace Database\Seeders;

use App\Models\JenisSurat;
use Illuminate\Database\Seeder;

class JenisSuratSeeder extends Seeder
{
    /** Data master: urutan dan namanya sama dengan daftar jenis surat di versi Node.js. */
    public function run(): void
    {
        foreach ([
            'SKAK' => 'Surat Keterangan Aktif Kuliah',
            'SIP'  => 'Surat Izin Penelitian',
            'SRB'  => 'Surat Rekomendasi Beasiswa',
            'PKL'  => 'Surat Pengantar Magang',
            'SKL'  => 'Surat Keterangan Lulus',
        ] as $kode => $nama) {
            JenisSurat::create(['kode' => $kode, 'nama' => $nama]);
        }
    }
}
