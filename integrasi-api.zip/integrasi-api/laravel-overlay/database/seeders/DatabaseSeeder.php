<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * php artisan migrate:fresh --seed
     * Urutan penting: jenis surat dan mahasiswa harus ada sebelum surat (foreign key).
     * Data palsu dalam jumlah banyak TIDAK ikut di sini supaya statistik tetap 5 surat:
     *   php artisan db:seed --class=DataPalsuSeeder
     */
    public function run(): void
    {
        $this->call([
            UserSeeder::class,
            JenisSuratSeeder::class,
            DosenSeeder::class,
            SuratSeeder::class,
        ]);
    }
}
