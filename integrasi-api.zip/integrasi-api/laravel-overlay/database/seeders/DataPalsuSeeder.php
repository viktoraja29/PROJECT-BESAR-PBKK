<?php

namespace Database\Seeders;

use App\Models\JenisSurat;
use App\Models\Mahasiswa;
use App\Models\Surat;
use Illuminate\Database\Seeder;

class DataPalsuSeeder extends Seeder
{
    /**
     * 20 mahasiswa palsu (factory), masing-masing dengan satu surat.
     * Untuk menguji paginasi dan memperlihatkan masalah N+1:
     *   php artisan db:seed --class=DataPalsuSeeder
     *   php artisan demo:n-plus-1
     */
    public function run(): void
    {
        $idJenis = JenisSurat::pluck('id');

        Mahasiswa::factory()->count(20)->create()->each(function (Mahasiswa $m) use ($idJenis) {
            Surat::ajukan([
                'mahasiswa_id'   => $m->id,
                'jenis_surat_id' => $idJenis->random(),
                'keperluan'      => 'Keperluan administrasi ' . fake()->sentence(4),
            ]);
        });
    }
}
