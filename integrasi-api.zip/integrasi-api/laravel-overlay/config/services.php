<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Third Party Services (bawaan Laravel)
    |--------------------------------------------------------------------------
    */

    'postmark' => [
        'key' => env('POSTMARK_API_KEY'),
    ],

    'resend' => [
        'key' => env('RESEND_API_KEY'),
    ],

    'ses' => [
        'key' => env('AWS_ACCESS_KEY_ID'),
        'secret' => env('AWS_SECRET_ACCESS_KEY'),
        'region' => env('AWS_DEFAULT_REGION', 'us-east-1'),
    ],

    'slack' => [
        'notifications' => [
            'bot_user_oauth_token' => env('SLACK_BOT_USER_OAUTH_TOKEN'),
            'channel' => env('SLACK_BOT_USER_DEFAULT_CHANNEL'),
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | Integrasi Surat
    |--------------------------------------------------------------------------
    */

    // Kunci untuk endpoint yang mengubah data (header X-API-Key)
    'api_key' => env('API_KEY', 'rahasia-demo'),

    // Webhook ke layanan notifikasi (Node.js)
    'notifikasi' => [
        'url' => env('NOTIFIKASI_URL', 'http://localhost:3000/api/v1/webhook/status-surat'),
        'key' => env('NOTIFIKASI_KEY', env('API_KEY', 'rahasia-demo')),
    ],

];
