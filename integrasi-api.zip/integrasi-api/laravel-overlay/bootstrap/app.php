<?php

use App\Http\Middleware\ApiKey;
use Illuminate\Auth\AuthenticationException;
use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;
use Illuminate\Http\Request;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;

return Application::configure(basePath: dirname(__DIR__))
    ->withRouting(
        web: __DIR__.'/../routes/web.php',
        api: __DIR__.'/../routes/api.php',
        commands: __DIR__.'/../routes/console.php',
        health: '/up',
    )
    ->withMiddleware(function (Middleware $middleware): void {
        // 'api.key' dipakai untuk komunikasi server-ke-server (mis. webhook)
        $middleware->alias(['api.key' => ApiKey::class]);
    })
    ->withExceptions(function (Exceptions $exceptions): void {
        // error di /api/* dibalas JSON, bukan halaman HTML
        $exceptions->shouldRenderJsonWhen(
            fn (Request $request) => $request->is('api/*')
        );

        $exceptions->render(function (NotFoundHttpException $e, Request $request) {
            if ($request->is('api/*')) {
                return response()->json(['message' => 'Data tidak ditemukan.'], 404);
            }
        });

        // token tidak ada / salah / kedaluwarsa -> 401 dengan pesan yang sama dengan Node.js
        $exceptions->render(function (AuthenticationException $e, Request $request) {
            if ($request->is('api/*')) {
                return response()->json(['message' => 'Tidak terautentikasi.'], 401);
            }
        });
    })->create();
