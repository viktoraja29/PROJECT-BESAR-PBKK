@echo off
rem Membuat project Laravel di folder laravel\ lalu menimpa dengan kode di laravel-overlay\
rem Syarat: PHP 8.2+, Composer, koneksi internet.
cd /d "%~dp0"

if exist laravel\artisan (
  echo Folder laravel\ sudah berisi project. Hapus dulu jika ingin mengulang.
  exit /b 1
)

call composer create-project laravel/laravel laravel --no-interaction
if errorlevel 1 exit /b 1

rem memasang Laravel Sanctum (token Bearer) + migration personal_access_tokens
pushd laravel
call php artisan install:api --no-interaction
popd

xcopy laravel-overlay laravel /E /Y /I /Q
type laravel-env-tambahan.txt >> laravel\.env

cd laravel
php artisan migrate --seed --force

echo.
echo Selesai. Jalankan Laravel dengan:
echo   cd laravel
echo   php artisan serve --port=8001
echo Akun demo: admin@kampus.test / password
