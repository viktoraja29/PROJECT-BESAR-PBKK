#!/usr/bin/env bash
# Membuat project Laravel di folder ./laravel lalu menimpa dengan kode di laravel-overlay/
# Syarat: PHP 8.2+, Composer, koneksi internet.
set -euo pipefail
cd "$(dirname "$0")"

if [ -f laravel/artisan ]; then
  echo "Folder laravel/ sudah berisi project. Hapus dulu jika ingin mengulang." >&2
  exit 1
fi

composer create-project laravel/laravel laravel --no-interaction

cd laravel
# memasang Laravel Sanctum (token Bearer) + migration personal_access_tokens
php artisan install:api --no-interaction
cd ..

cp -R laravel-overlay/. laravel/
cat laravel-env-tambahan.txt >> laravel/.env

cd laravel
php artisan migrate --seed --force

echo
echo "Selesai. Jalankan Laravel dengan:"
echo "  cd laravel && php artisan serve --port=8001"
echo "Akun demo: admin@kampus.test / password"
