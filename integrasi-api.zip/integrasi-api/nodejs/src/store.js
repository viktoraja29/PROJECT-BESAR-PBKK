// ~ Model Eloquent: data disimpan di array memori (hilang saat server restart)
import { STATUS, JENIS } from './status.js';

// Format ISO 8601 dengan zona waktu +07:00, contoh: 2026-09-20T15:45:00+07:00
export function toIso(date = new Date()) {
  const geser = new Date(date.getTime() + 7 * 3600 * 1000);
  return geser.toISOString().replace(/\.\d{3}Z$/, '+07:00');
}

const nomorSurat = (id) => `SRT/${String(id).padStart(4, '0')}/2026`;

function seed() {
  return [
    {
      id: 1,
      nomor: nomorSurat(1),
      nama: 'Muhammad Farhan',
      nim: '2443027',
      jenis: 'Surat Keterangan Aktif Kuliah',
      keperluan: 'Persyaratan administrasi beasiswa tahun ajaran 2026/2027.',
      status: 'selesai',
      riwayat: [
        { status: 'diajukan', waktu: '2026-09-17T09:00:00+07:00', catatan: 'Pengajuan dibuat oleh mahasiswa.' },
        { status: 'diproses', waktu: '2026-09-17T13:30:00+07:00', catatan: 'Sedang diverifikasi bagian akademik.' },
        { status: 'selesai', waktu: '2026-09-18T10:15:00+07:00', catatan: 'Surat sudah dapat diambil.' },
      ],
      dibuat_pada: '2026-09-17T09:00:00+07:00',
    },
    {
      id: 2,
      nomor: nomorSurat(2),
      nama: 'Muhammad Syahreza',
      nim: '2443039',
      jenis: 'Surat Pengantar Magang',
      keperluan: 'Magang semester 7 di perusahaan teknologi di Samarinda.',
      status: 'diproses',
      riwayat: [
        { status: 'diajukan', waktu: '2026-09-18T08:20:00+07:00', catatan: 'Pengajuan dibuat oleh mahasiswa.' },
        { status: 'diproses', waktu: '2026-09-19T11:00:00+07:00', catatan: 'Menunggu tanda tangan ketua program studi.' },
      ],
      dibuat_pada: '2026-09-18T08:20:00+07:00',
    },
    {
      id: 3,
      nomor: nomorSurat(3),
      nama: 'Shanjay Wijaya Indra Kirana',
      nim: '2443014',
      jenis: 'Surat Izin Penelitian',
      keperluan: 'Penelitian skripsi tentang pertanian di desa binaan.',
      status: 'ditolak',
      riwayat: [
        { status: 'diajukan', waktu: '2026-09-19T10:10:00+07:00', catatan: 'Pengajuan dibuat oleh mahasiswa.' },
        { status: 'ditolak', waktu: '2026-09-19T14:45:00+07:00', catatan: 'Proposal belum disetujui pembimbing.' },
      ],
      dibuat_pada: '2026-09-19T10:10:00+07:00',
    },
    {
      id: 4,
      nomor: nomorSurat(4),
      nama: 'Viktor',
      nim: '2443085',
      jenis: 'Surat Rekomendasi Beasiswa',
      keperluan: 'Pendaftaran beasiswa prestasi tingkat provinsi.',
      status: 'diajukan',
      riwayat: [
        { status: 'diajukan', waktu: '2026-09-20T15:45:00+07:00', catatan: 'Pengajuan dibuat oleh mahasiswa.' },
      ],
      dibuat_pada: '2026-09-20T15:45:00+07:00',
    },
    {
      id: 5,
      nomor: nomorSurat(5),
      nama: 'Julivian Dodi',
      nim: '2443028',
      jenis: 'Surat Keterangan Lulus',
      keperluan: 'Persyaratan pendaftaran wisuda periode berikutnya.',
      status: 'diproses',
      riwayat: [
        { status: 'diajukan', waktu: '2026-09-21T08:30:00+07:00', catatan: 'Pengajuan dibuat oleh mahasiswa.' },
        { status: 'diproses', waktu: '2026-09-21T14:00:00+07:00', catatan: 'Sedang diperiksa bagian akademik.' },
      ],
      dibuat_pada: '2026-09-21T08:30:00+07:00',
    },
  ];
}

let daftar = seed();
let nextId = 6;
const notifikasi = [];
let nextNotifId = 1;

export const store = {
  list({ status, q, page, perPage }) {
    const kata = (q ?? '').toString().trim().toLowerCase();
    const cocok = daftar
      .filter((s) => !status || s.status === status)
      .filter((s) => !kata || s.nama.toLowerCase().includes(kata) || s.nim.toLowerCase().includes(kata))
      .sort((a, b) => b.id - a.id);
    const mulai = (page - 1) * perPage;
    return { items: cocok.slice(mulai, mulai + perPage), total: cocok.length };
  },

  find(id) {
    return daftar.find((s) => s.id === id);
  },

  create(data) {
    const id = nextId++;
    const sekarang = toIso();
    const surat = {
      id,
      nomor: nomorSurat(id),
      nama: String(data.nama).trim(),
      nim: String(data.nim).trim(),
      jenis: data.jenis,
      keperluan: String(data.keperluan).trim(),
      status: 'diajukan',
      riwayat: [{ status: 'diajukan', waktu: sekarang, catatan: 'Pengajuan dibuat oleh mahasiswa.' }],
      dibuat_pada: sekarang,
    };
    daftar.push(surat);
    return surat;
  },

  ubahStatus(id, status, catatan = '') {
    const surat = this.find(id);
    surat.status = status;
    surat.riwayat.push({
      status,
      waktu: toIso(),
      catatan: catatan.trim() !== '' ? catatan.trim() : `Status diubah menjadi ${STATUS[status].label}.`,
    });
    return surat;
  },

  remove(id) {
    daftar = daftar.filter((s) => s.id !== id);
  },

  // Tugas 3: GET /api/v1/statistik
  statistik() {
    const hasil = { semua: daftar.length };
    for (const kode of Object.keys(STATUS)) {
      hasil[kode] = daftar.filter((s) => s.status === kode).length;
    }
    // sama dengan Laravel: jumlah surat per jenis surat
    hasil.per_jenis = JENIS.map((jenis) => ({
      jenis,
      jumlah: daftar.filter((s) => s.jenis === jenis).length,
    }));
    return hasil;
  },

  // Tugas 5: notifikasi dari webhook
  tambahNotifikasi({ event, data }) {
    const item = { id: nextNotifId++, event, data, diterima_pada: toIso() };
    notifikasi.push(item);
    return item;
  },

  daftarNotifikasi() {
    return [...notifikasi].reverse();
  },
};
