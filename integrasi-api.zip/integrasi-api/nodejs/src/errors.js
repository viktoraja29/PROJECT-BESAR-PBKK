export class HttpError extends Error {
  constructor(status, message, errors) {
    super(message);
    this.status = status;
    this.errors = errors; // hanya diisi untuk 422
  }
}

// Format sama dengan Laravel:
// { message: "Nama wajib diisi. (dan 1 error lainnya)", errors: { field: [pesan] } }
export function validationError(errors) {
  const semua = Object.values(errors).flat();
  const sisa = semua.length - 1;
  const message = sisa > 0 ? `${semua[0]} (dan ${sisa} error lainnya)` : semua[0];
  return new HttpError(422, message, errors);
}
