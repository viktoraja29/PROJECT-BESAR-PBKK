import express from 'express';
import cors from 'cors';
import suratRouter from './routes/surat.js';
import authRouter from './routes/auth.js';
import { apiKey } from './middleware/apiKey.js';
import { bearerAuth } from './middleware/bearerAuth.js';
import { errorHandler } from './middleware/errorHandler.js';
import { HttpError, validationError } from './errors.js';
import { JENIS } from './status.js';
import { store } from './store.js';
import { validasiWebhook } from './validate.js';

const app = express();
app.disable('x-powered-by');
app.use(cors()); // izinkan origin lain (frontend di port 8000 / 5500)
app.use(express.json({ limit: '100kb' })); // body JSON -> req.body

app.get('/', (req, res) => {
  res.json({ message: 'API Pengajuan Surat (Node.js). Lihat /api/v1/surat' });
});

app.get('/api/v1/jenis-surat', (req, res) => res.json({ data: JENIS }));

// Tugas 3: statistik jumlah surat per status
app.get('/api/v1/statistik', (req, res) => res.json({ data: store.statistik() }));

// Tugas 6: login / logout / me (token Bearer)
app.use('/api/v1', authRouter);

app.use('/api/v1/surat', suratRouter);

// Webhook: dipanggil Laravel saat status surat berubah (slide 25)
app.post('/api/v1/webhook/status-surat', apiKey, (req, res) => {
  const body = req.body ?? {};
  const errors = validasiWebhook(body);
  if (Object.keys(errors).length) throw validationError(errors);

  const { event, data } = body;
  console.log(`[NOTIFIKASI] ${event}: ${data.nomor} -> ${data.status}`);
  store.tambahNotifikasi({ event, data }); // Tugas 5

  // 202: diterima, diproses nanti
  res.status(202).json({ message: 'Notifikasi diterima.' });
});

// Tugas 5: lihat notifikasi yang sudah diterima
app.get('/api/v1/notifikasi', bearerAuth, (req, res) => res.json({ data: store.daftarNotifikasi() }));

// endpoint tidak ada -> 404 JSON
app.use((req, res, next) => next(new HttpError(404, 'Endpoint tidak ditemukan.')));

app.use(errorHandler); // paling akhir

export default app;
