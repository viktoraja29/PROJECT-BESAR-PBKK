// ~ API Resource Laravel: cetakan format JSON yang dikirim ke client
import { STATUS } from './status.js';

export function suratResource(s, { detail = false } = {}) {
  const status = STATUS[s.status];
  return {
    id: s.id,
    nomor: s.nomor,
    nama: s.nama,
    nim: s.nim,
    jenis: s.jenis,
    keperluan: s.keperluan,
    status: s.status,
    status_label: status.label,
    aksi_berikutnya: status.berikutnya.map((kode) => ({ status: kode, label: STATUS[kode].aksi })),
    // riwayat hanya di detail, tidak di daftar
    ...(detail && { riwayat: s.riwayat }),
    dibuat_pada: s.dibuat_pada,
  };
}

// Bungkus daftar -> { data, links, meta } (sama dengan paginator Laravel)
export function paginated(req, items, { total, page, perPage }, mapper) {
  const lastPage = Math.max(1, Math.ceil(total / perPage));
  const base = `${req.protocol}://${req.get('host')}${req.baseUrl}`;

  const link = (p) => {
    if (p < 1 || p > lastPage) return null;
    const params = new URLSearchParams();
    for (const [k, v] of Object.entries(req.query)) {
      if (k !== 'page' && typeof v === 'string' && v !== '') params.set(k, v);
    }
    params.set('page', String(p));
    return `${base}?${params}`;
  };

  return {
    data: items.map(mapper),
    links: { first: link(1), last: link(lastPage), prev: link(page - 1), next: link(page + 1) },
    meta: {
      current_page: page,
      from: items.length ? (page - 1) * perPage + 1 : null,
      to: items.length ? (page - 1) * perPage + items.length : null,
      last_page: lastPage,
      per_page: perPage,
      total,
    },
  };
}
