// ~ enum StatusSurat di Laravel
export const JENIS = [
  'Surat Keterangan Aktif Kuliah',
  'Surat Izin Penelitian',
  'Surat Rekomendasi Beasiswa',
  'Surat Pengantar Magang',
  'Surat Keterangan Lulus',
];

// label = untuk tampilan status, aksi = teks tombol menuju status tsb,
// berikutnya = status yang boleh dituju dari status ini
export const STATUS = {
  diajukan: { label: 'Diajukan', aksi: 'Ajukan', berikutnya: ['diproses', 'ditolak'] },
  diproses: { label: 'Diproses', aksi: 'Proses', berikutnya: ['selesai', 'ditolak'] },
  selesai: { label: 'Selesai', aksi: 'Selesaikan', berikutnya: [] },
  ditolak: { label: 'Ditolak', aksi: 'Tolak', berikutnya: [] },
};

export function bisaBerubahKe(dari, ke) {
  return STATUS[dari]?.berikutnya.includes(ke) ?? false;
}
