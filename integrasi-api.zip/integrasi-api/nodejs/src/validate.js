// ~ FormRequest Laravel: aturan validasi + pesan error per field
import { JENIS, STATUS } from './status.js';

function tambah(errors, field, pesan) {
  (errors[field] ??= []).push(pesan);
}

export function validasiSurat(body) {
  const errors = {};

  const nama = typeof body.nama === 'string' ? body.nama.trim() : '';
  if (nama === '') tambah(errors, 'nama', 'Nama wajib diisi.');
  else if (nama.length > 100) tambah(errors, 'nama', 'Nama maksimal 100 karakter.');

  const nim = body.nim == null ? '' : String(body.nim).trim();
  if (!/^\d{5,15}$/.test(nim)) tambah(errors, 'nim', 'NIM harus berupa angka (5-15 digit).');

  if (!JENIS.includes(body.jenis)) tambah(errors, 'jenis', 'Pilih jenis surat.');

  const keperluan = typeof body.keperluan === 'string' ? body.keperluan.trim() : '';
  if (keperluan.length < 10) tambah(errors, 'keperluan', 'Keperluan minimal 10 karakter.');

  return errors;
}

export function validasiStatus(body) {
  const errors = {};

  if (body.status == null || body.status === '') {
    tambah(errors, 'status', 'Status wajib diisi.');
  } else if (!Object.hasOwn(STATUS, body.status)) {
    tambah(errors, 'status', 'Status tidak valid.');
  }

  if (body.catatan != null && (typeof body.catatan !== 'string' || body.catatan.length > 255)) {
    tambah(errors, 'catatan', 'Catatan harus berupa teks maksimal 255 karakter.');
  }

  return errors;
}

export function validasiLogin(body) {
  const errors = {};

  const email = typeof body.email === 'string' ? body.email.trim() : '';
  if (email === '') tambah(errors, 'email', 'Email wajib diisi.');
  else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) tambah(errors, 'email', 'Email tidak valid.');

  if (typeof body.password !== 'string' || body.password === '') {
    tambah(errors, 'password', 'Password wajib diisi.');
  }

  return errors;
}

export function validasiWebhook(body) {
  const errors = {};
  if (typeof body.event !== 'string' || body.event === '') tambah(errors, 'event', 'Event wajib diisi.');
  if (body.data == null || typeof body.data !== 'object') tambah(errors, 'data', 'Data wajib berupa objek.');
  return errors;
}
