// ~ throttle:30,1 di Laravel. Pengajuan surat terbuka untuk publik,
// jadi dibatasi maks 30 request per menit per IP agar tidak disalahgunakan.
import { HttpError } from '../errors.js';

const catatan = new Map();

export function batasiPengajuan(req, res, next) {
  const sekarang = Date.now();
  const terbaru = (catatan.get(req.ip) ?? []).filter((t) => sekarang - t < 60_000);
  terbaru.push(sekarang);
  catatan.set(req.ip, terbaru);

  if (terbaru.length > 30) {
    return next(new HttpError(429, 'Terlalu banyak pengajuan. Coba lagi sebentar lagi.'));
  }
  next();
}
