// ~ withExceptions() di bootstrap/app.php Laravel: semua error dibalas JSON
import { HttpError } from '../errors.js';

// Express mengenali middleware error dari 4 parameter (err, req, res, next)
// eslint-disable-next-line no-unused-vars
export function errorHandler(err, req, res, next) {
  if (err.type === 'entity.parse.failed') {
    return res.status(400).json({ message: 'Body request bukan JSON yang valid.' });
  }
  if (err.type === 'entity.too.large') {
    return res.status(413).json({ message: 'Body request terlalu besar.' });
  }
  if (err instanceof HttpError) {
    return res.status(err.status).json({
      message: err.message,
      ...(err.errors && { errors: err.errors }),
    });
  }

  // detail error hanya di log server, JANGAN dikirim ke client
  console.error(err);
  res.status(500).json({ message: 'Terjadi kesalahan di server.' });
}
