// ~ middleware auth:sanctum di Laravel
import { HttpError } from '../errors.js';
import { auth } from '../auth.js';

export function bearerAuth(req, res, next) {
  const [skema, token] = (req.get('Authorization') ?? '').split(' ');
  const user = skema?.toLowerCase() === 'bearer' && token ? auth.userDariToken(token) : null;

  if (!user) return next(new HttpError(401, 'Tidak terautentikasi.'));

  req.user = user;
  req.token = token;
  next();
}
