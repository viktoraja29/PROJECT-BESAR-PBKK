// ~ Middleware ApiKey di Laravel
import crypto from 'node:crypto';
import { HttpError } from '../errors.js';

const hash = (teks) => crypto.createHash('sha256').update(String(teks)).digest();

export function apiKey(req, res, next) {
  const seharusnya = process.env.API_KEY || 'rahasia-demo';
  const dikirim = req.get('X-API-Key') ?? '';

  // bandingkan hash dengan timingSafeEqual agar aman dari timing attack
  if (dikirim === '' || !crypto.timingSafeEqual(hash(dikirim), hash(seharusnya))) {
    return next(new HttpError(401, 'API key tidak valid.'));
  }
  next();
}
