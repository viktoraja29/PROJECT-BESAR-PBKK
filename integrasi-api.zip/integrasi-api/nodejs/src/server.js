import app from './app.js';

const PORT = Number(process.env.PORT) || 3000;

app.listen(PORT, '0.0.0.0', () => {
  console.log(`API Node.js berjalan di http://localhost:${PORT}/api/v1/surat`);
});
