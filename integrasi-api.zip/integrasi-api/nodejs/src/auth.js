// ~ Laravel Sanctum: pengguna + token Bearer (disimpan di memori)
import crypto from 'node:crypto';

const sha256 = (teks) => crypto.createHash('sha256').update(teks).digest('hex');

function hashPassword(password, salt = crypto.randomBytes(16).toString('hex')) {
  return `${salt}:${crypto.scryptSync(password, salt, 32).toString('hex')}`;
}

function cocokPassword(password, tersimpan) {
  const [salt, hash] = tersimpan.split(':');
  return crypto.timingSafeEqual(crypto.scryptSync(password, salt, 32), Buffer.from(hash, 'hex'));
}

// Pengguna demo. Password TIDAK disimpan polos, hanya hash (scrypt + salt).
const users = [
  { id: 1, nama: 'Admin Akademik', email: 'admin@kampus.test', password: hashPassword('password') },
];
// dipakai agar waktu respons sama baik email ada maupun tidak (cegah user enumeration)
const HASH_PALSU = hashPassword('palsu');

const publik = (u) => ({ id: u.id, nama: u.nama, email: u.email });

const TTL_MS = 2 * 60 * 60 * 1000; // token berlaku 2 jam
const tokens = new Map(); // sha256(token) -> { userId, kedaluwarsa }

export const auth = {
  login(email, password) {
    const user = users.find((u) => u.email === email.trim().toLowerCase());
    const cocok = cocokPassword(password, user?.password ?? HASH_PALSU);
    if (!user || !cocok) return null;

    const token = crypto.randomBytes(32).toString('hex');
    tokens.set(sha256(token), { userId: user.id, kedaluwarsa: Date.now() + TTL_MS });
    return { token, user: publik(user) };
  },

  userDariToken(token) {
    const kunci = sha256(token);
    const rekam = tokens.get(kunci);
    if (!rekam) return null;
    if (rekam.kedaluwarsa < Date.now()) {
      tokens.delete(kunci);
      return null;
    }
    return publik(users.find((u) => u.id === rekam.userId));
  },

  logout(token) {
    tokens.delete(sha256(token));
  },
};
