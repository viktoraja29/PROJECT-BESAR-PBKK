// ~ AuthController di Laravel
import { Router } from 'express';
import { auth } from '../auth.js';
import { HttpError, validationError } from '../errors.js';
import { bearerAuth } from '../middleware/bearerAuth.js';
import { validasiLogin } from '../validate.js';

const router = Router();

// pembatas sederhana: maks 10 percobaan login per menit per IP (~ throttle:10,1)
const percobaan = new Map();
function batasiLogin(ip) {
  const sekarang = Date.now();
  const terbaru = (percobaan.get(ip) ?? []).filter((t) => sekarang - t < 60_000);
  terbaru.push(sekarang);
  percobaan.set(ip, terbaru);
  if (terbaru.length > 10) {
    throw new HttpError(429, 'Terlalu banyak percobaan login. Coba lagi sebentar lagi.');
  }
}

// POST /api/v1/login -> { data: { token, token_type, user } }
router.post('/login', (req, res) => {
  batasiLogin(req.ip);

  const body = req.body ?? {};
  const errors = validasiLogin(body);
  if (Object.keys(errors).length) throw validationError(errors);

  const hasil = auth.login(String(body.email), String(body.password));
  if (!hasil) throw validationError({ email: ['Email atau password salah.'] });

  res.json({ data: { token: hasil.token, token_type: 'Bearer', user: hasil.user } });
});

// GET /api/v1/me
router.get('/me', bearerAuth, (req, res) => {
  res.json({ data: req.user });
});

// POST /api/v1/logout -> 204 (token dicabut)
router.post('/logout', bearerAuth, (req, res) => {
  auth.logout(req.token);
  res.status(204).end();
});

export default router;
