// ~ SuratController di Laravel
import { Router } from 'express';
import { bearerAuth } from '../middleware/bearerAuth.js';
import { batasiPengajuan } from '../middleware/batasiPengajuan.js';
import { HttpError, validationError } from '../errors.js';
import { store } from '../store.js';
import { STATUS, bisaBerubahKe } from '../status.js';
import { suratResource, paginated } from '../resource.js';
import { validasiSurat, validasiStatus } from '../validate.js';

const router = Router();

// mirip route model binding: semua route dengan :id mencari suratnya dulu
router.param('id', (req, res, next, id) => {
  req.surat = store.find(Number(id));
  if (!req.surat) return next(new HttpError(404, 'Data tidak ditemukan.'));
  next();
});

// GET /api/v1/surat?status=diajukan&q=dewi&page=2&per_page=5
router.get('/', (req, res) => {
  const page = Math.max(1, parseInt(req.query.page, 10) || 1);
  const perPage = Math.min(50, Math.max(1, parseInt(req.query.per_page, 10) || 10));
  const status = typeof req.query.status === 'string' ? req.query.status : undefined;
  const q = typeof req.query.q === 'string' ? req.query.q : undefined;

  const { items, total } = store.list({ status, q, page, perPage });
  res.json(paginated(req, items, { total, page, perPage }, (s) => suratResource(s)));
});

// POST /api/v1/surat  (terbuka untuk mahasiswa/publik, tanpa login; dibatasi rate limit)
router.post('/', batasiPengajuan, (req, res) => {
  const errors = validasiSurat(req.body ?? {});
  if (Object.keys(errors).length) throw validationError(errors); // -> 422

  const surat = store.create(req.body);
  res
    .status(201)
    .location(`${req.baseUrl}/${surat.id}`)
    .json({ data: suratResource(surat, { detail: true }) });
});

// GET /api/v1/surat/:id
router.get('/:id', (req, res) => {
  res.json({ data: suratResource(req.surat, { detail: true }) });
});

// PATCH /api/v1/surat/:id/status
router.patch('/:id/status', bearerAuth, (req, res) => {
  const body = req.body ?? {};
  const errors = validasiStatus(body);
  if (Object.keys(errors).length) throw validationError(errors);

  const lama = req.surat.status;
  const baru = body.status;
  if (!bisaBerubahKe(lama, baru)) {
    // aturan bisnis gagal -> format 422 yang sama dengan error validasi
    throw validationError({
      status: [`Status ${STATUS[lama].label} tidak bisa diubah ke ${STATUS[baru].label}.`],
    });
  }

  const surat = store.ubahStatus(req.surat.id, baru, body.catatan ?? '');
  res.json({ data: suratResource(surat, { detail: true }) });
});

// DELETE /api/v1/surat/:id
router.delete('/:id', bearerAuth, (req, res) => {
  store.remove(req.surat.id);
  res.status(204).end();
});

export default router;
