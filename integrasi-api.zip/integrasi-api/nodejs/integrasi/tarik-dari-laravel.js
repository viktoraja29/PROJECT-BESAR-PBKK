// Node.js sebagai CLIENT: menarik seluruh data surat dari API Laravel (slide 26)
// Jalankan: npm run tarik-laravel   (Laravel harus aktif di port 8001)

const SUMBER_API = process.env.SUMBER_API || 'http://localhost:8001/api/v1';

async function getJson(url) {
  const res = await fetch(url, {
    headers: { Accept: 'application/json' },
    signal: AbortSignal.timeout(5000), // selalu pasang timeout
  });
  const body = await res.json().catch(() => null);
  if (!res.ok) throw new Error(`HTTP ${res.status}: ${body?.message ?? 'tanpa pesan'}`);
  return body;
}

// ikuti links.next sampai null (jangan menebak jumlah halaman)
async function ambilSemuaSurat() {
  const semua = [];
  let url = `${SUMBER_API}/surat?per_page=50`;
  while (url) {
    const { data, links } = await getJson(url);
    semua.push(...data);
    url = links.next;
  }
  return semua;
}

async function main() {
  console.log(`Sumber: ${SUMBER_API}`);
  const surat = await ambilSemuaSurat();
  console.log(`Total surat: ${surat.length}`);

  // kelompokkan per status
  const kelompok = new Map();
  for (const s of surat) {
    if (!kelompok.has(s.status_label)) kelompok.set(s.status_label, []);
    kelompok.get(s.status_label).push(s.nim);
  }
  for (const [label, daftarNim] of kelompok) {
    console.log(`  ${label.padEnd(9)} ${daftarNim.length} (${daftarNim.join(', ')})`);
  }
}

main().catch((err) => {
  console.error(`Gagal menarik data: ${err.message}`);
  process.exit(1);
});
