// Satu-satunya tempat yang menulis fetch(). Komponen UI hanya memanggil `api.*`.
// Ganti backend / urus token cukup di file ini.

export const BACKENDS = {
  node: 'http://localhost:3000/api/v1',
  laravel: 'http://localhost:8001/api/v1',
};

let backend = 'node';
let baseUrl = BACKENDS.node;
let logger = () => {};
let onUnauthorized = () => {};

// ---------- sesi login (token Bearer), terpisah per backend ----------
// Disimpan di sessionStorage (hilang saat tab ditutup). Dibungkus try/catch karena
// storage bisa dinonaktifkan browser; variabel `sesi` tetap menjaga sesi selama halaman terbuka.
let sesi = { token: null, user: null };

const baca = (kunci) => {
  try {
    return sessionStorage.getItem(kunci);
  } catch {
    return null;
  }
};
const tulis = (kunci, nilai) => {
  try {
    if (nilai == null) sessionStorage.removeItem(kunci);
    else sessionStorage.setItem(kunci, nilai);
  } catch {
    /* abaikan */
  }
};

function muatSesi() {
  let user = null;
  try {
    user = JSON.parse(baca(`user:${backend}`));
  } catch {
    user = null;
  }
  sesi = { token: baca(`token:${backend}`), user };
}

export const getToken = () => sesi.token;
export const getUser = () => sesi.user;

export function simpanSesi({ token, user }) {
  sesi = { token, user };
  tulis(`token:${backend}`, token);
  tulis(`user:${backend}`, JSON.stringify(user));
}

export function hapusSesi() {
  sesi = { token: null, user: null };
  tulis(`token:${backend}`, null);
  tulis(`user:${backend}`, null);
}

export function setBackend(kunci) {
  backend = kunci;
  baseUrl = BACKENDS[kunci];
  muatSesi();
}
export function setLogger(fn) {
  logger = fn;
}
export function setOnUnauthorized(fn) {
  onUnauthorized = fn;
}

muatSesi();

// ---------- request ----------
export class ApiError extends Error {
  constructor(status, body) {
    super(body?.message ?? `Terjadi kesalahan (HTTP ${status}).`);
    this.status = status;
    this.errors = body?.errors ?? {}; // { nama: ['Nama wajib diisi.'] } untuk 422
  }
}

export async function request(method, path, { query, body } = {}) {
  const url = new URL(baseUrl + path);
  for (const [k, v] of Object.entries(query ?? {})) {
    if (v !== '' && v != null) url.searchParams.set(k, v);
  }

  const headers = { Accept: 'application/json' };
  if (body) headers['Content-Type'] = 'application/json';
  if (sesi.token) headers.Authorization = `Bearer ${sesi.token}`;

  const mulai = performance.now();
  let res;
  try {
    res = await fetch(url, { method, headers, body: body ? JSON.stringify(body) : undefined });
  } catch {
    logger({ method, url: url.toString(), status: 'ERR', ms: Math.round(performance.now() - mulai) });
    throw new ApiError(0, {
      message: 'Tidak bisa terhubung ke server. Pastikan backend sudah berjalan.',
    });
  }
  logger({ method, url: url.toString(), status: res.status, ms: Math.round(performance.now() - mulai) });

  const data = res.status === 204 ? null : await res.json().catch(() => null);

  // 401 di luar login = token kedaluwarsa / dicabut: bersihkan sesi, minta login ulang
  if (res.status === 401 && path !== '/login') {
    hapusSesi();
    onUnauthorized();
  }

  // PENTING: fetch TIDAK melempar error untuk 4xx/5xx, harus dicek sendiri
  if (!res.ok) throw new ApiError(res.status, data);
  return data;
}

export const api = {
  login: (email, password) => request('POST', '/login', { body: { email, password } }),
  logout: () => request('POST', '/logout'),
  me: () => request('GET', '/me'),
  jenisSurat: () => request('GET', '/jenis-surat'),
  statistik: () => request('GET', '/statistik'),
  daftarSurat: (query) => request('GET', '/surat', { query }),
  detailSurat: (id) => request('GET', `/surat/${id}`),
  ajukanSurat: (data) => request('POST', '/surat', { body: data }),
  ubahStatus: (id, status, catatan) =>
    request('PATCH', `/surat/${id}/status`, { body: { status, catatan } }),
  hapusSurat: (id) => request('DELETE', `/surat/${id}`),
};
