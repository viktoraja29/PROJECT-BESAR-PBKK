import {
  api,
  setBackend,
  setLogger,
  setOnUnauthorized,
  ApiError,
  getToken,
  getUser,
  simpanSesi,
  hapusSesi,
} from './api.js';

const $ = (selector) => document.querySelector(selector);

// data dari API di-escape sebelum masuk HTML (mencegah XSS)
const esc = (v) =>
  String(v ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);

const tanggal = (iso) =>
  iso ? new Date(iso).toLocaleString('id-ID', { dateStyle: 'medium', timeStyle: 'short' }) : '-';

const TABS = [
  { status: '', label: 'Semua', kunci: 'semua' },
  { status: 'diajukan', label: 'Diajukan', kunci: 'diajukan' },
  { status: 'diproses', label: 'Diproses', kunci: 'diproses' },
  { status: 'selesai', label: 'Selesai', kunci: 'selesai' },
  { status: 'ditolak', label: 'Ditolak', kunci: 'ditolak' },
];

const state = { status: '', q: '', page: 1, id: null, statistik: null, detail: null };

// ---------- alert & log ----------
function tampilkanAlert(pesan, ok = false) {
  const el = $('#alert');
  el.textContent = pesan;
  el.className = ok ? 'alert ok' : 'alert';
  el.hidden = false;
}
function sembunyikanAlert() {
  $('#alert').hidden = true;
}
const alertHtml = (pesan) => `<div class="alert">${esc(pesan)}</div>`;

setLogger(({ method, url, status, ms }) => {
  const li = document.createElement('li');
  li.className = typeof status === 'number' && status < 400 ? 'ok' : 'gagal';
  li.textContent = `${method} ${url} -> ${status} (${ms} ms)`;
  const log = $('#log');
  log.prepend(li);
  while (log.children.length > 12) log.lastChild.remove();
});

// ---------- tab filter + statistik (Tugas 4) ----------
async function muatStatistik() {
  try {
    state.statistik = (await api.statistik()).data;
  } catch {
    state.statistik = null; // tab tetap tampil tanpa angka
  }
  renderTabs();
}

function renderTabs() {
  $('#tabs').innerHTML = TABS.map((t) => {
    const jumlah = state.statistik ? ` (${state.statistik[t.kunci] ?? 0})` : '';
    const aktif = state.status === t.status ? ' aktif' : '';
    return `<button type="button" class="${aktif.trim()}" data-status="${esc(t.status)}">${esc(t.label)}${jumlah}</button>`;
  }).join('');
}

// ---------- daftar: loading -> data / error ----------
async function muatDaftar() {
  $('#daftar').innerHTML = '<div class="kosong">Memuat data...</div>'; // 1. loading
  $('#pager').innerHTML = '';
  try {
    const { data, meta } = await api.daftarSurat({
      status: state.status,
      q: state.q,
      page: state.page,
      per_page: 5,
    });
    renderDaftar(data, meta); // 2. sukses
  } catch (e) {
    $('#daftar').innerHTML = alertHtml(e.message); // 3. gagal
  }
}

function renderDaftar(list, meta) {
  if (list.length === 0) {
    $('#daftar').innerHTML = '<div class="kosong">Tidak ada surat.</div>';
  } else {
    $('#daftar').innerHTML = list
      .map(
        (s) => `
      <button type="button" class="item${s.id === state.id ? ' aktif' : ''}" data-id="${s.id}">
        <span>${esc(s.nama)}<small>${esc(s.nim)} &middot; ${esc(s.jenis)}</small></span>
        <span class="status status-${esc(s.status)}">${esc(s.status_label)}</span>
      </button>`,
      )
      .join('');
  }

  $('#pager').innerHTML = `
    <button type="button" class="sekunder" data-hal="${meta.current_page - 1}" ${meta.current_page <= 1 ? 'disabled' : ''}>Sebelumnya</button>
    <span>Halaman ${meta.current_page} / ${meta.last_page} &middot; ${meta.total} surat</span>
    <button type="button" class="sekunder" data-hal="${meta.current_page + 1}" ${meta.current_page >= meta.last_page ? 'disabled' : ''}>Berikutnya</button>`;
}

// ---------- detail ----------
async function bukaDetail(id) {
  state.id = id;
  $('#detail').textContent = 'Memuat detail...';
  try {
    const { data } = await api.detailSurat(id);
    renderDetail(data);
    document.querySelectorAll('.item').forEach((el) => el.classList.toggle('aktif', Number(el.dataset.id) === id));
  } catch (e) {
    $('#detail').innerHTML = alertHtml(e.message);
  }
}

function renderDetail(s) {
  state.detail = s;

  // tombol dibuat dari aksi_berikutnya: aturan status cukup ditulis di server.
  // Hanya tampil jika sudah login (server tetap menolak 401 tanpa token).
  const login = Boolean(getToken());
  const tombol = login
    ? s.aksi_berikutnya // hanya admin (login) yang melihat tombol proses dan hapus
        .map((a) => `<button type="button" data-aksi="${esc(a.status)}">${esc(a.label)}</button>`)
        .join('')
    : '';
  const tombolHapus = login ? `<button type="button" class="bahaya" data-hapus="${s.id}">Hapus</button>` : '';

  $('#detail').innerHTML = `
    <strong>${esc(s.nomor)}</strong>
    <span class="status status-${esc(s.status)}">${esc(s.status_label)}</span>
    <dl>
      <dt>Nama</dt><dd>${esc(s.nama)}</dd>
      <dt>NIM</dt><dd>${esc(s.nim)}</dd>
      <dt>Jenis</dt><dd>${esc(s.jenis)}</dd>
      <dt>Keperluan</dt><dd>${esc(s.keperluan)}</dd>
      <dt>Dibuat</dt><dd>${esc(tanggal(s.dibuat_pada))}</dd>
    </dl>
    ${login ? `<div class="aksi">${tombol}${tombolHapus}</div>` : '<p class="hint">Login untuk mengubah status surat.</p>'}
    <strong>Riwayat</strong>
    <ul class="riwayat">
      ${(s.riwayat ?? [])
        .map((r) => `<li>${esc(r.status)} <small>${esc(tanggal(r.waktu))}</small><br>${esc(r.catatan)}</li>`)
        .join('')}
    </ul>`;
}

// jalankan aksi yang mengubah data, lalu segarkan tampilan
async function jalankan(aksi) {
  sembunyikanAlert();
  try {
    await aksi();
  } catch (e) {
    tampilkanAlert(e.message); // 401, 404, 422 (aturan status), 500, offline
  }
  await Promise.all([muatStatistik(), muatDaftar()]);
}

// ---------- form: validasi 422 per field ----------
function bersihkanError(form) {
  form.querySelectorAll('[data-error]').forEach((el) => (el.textContent = ''));
}

async function kirimForm(form) {
  const tombol = $('#kirim');
  bersihkanError(form);
  sembunyikanAlert();
  tombol.disabled = true; // cegah klik ganda
  try {
    const input = Object.fromEntries(new FormData(form));
    const { data } = await api.ajukanSurat(input); // 201
    form.reset();
    tampilkanAlert(`Surat ${data.nomor} berhasil diajukan.`, true);
    state.status = '';
    state.page = 1;
    await Promise.all([muatStatistik(), muatDaftar()]);
    await bukaDetail(data.id);
  } catch (e) {
    if (e instanceof ApiError && e.status === 422) {
      // kunci di errors = nama field form -> tempel pesan tepat di bawah input
      for (const [field, pesan] of Object.entries(e.errors)) {
        const el = form.querySelector(`[data-error="${field}"]`);
        if (el) el.textContent = pesan[0];
      }
    } else {
      tampilkanAlert(e.message);
    }
  } finally {
    tombol.disabled = false;
  }
}

// ---------- login / logout (Tugas 6) ----------
function renderAuth() {
  const masuk = Boolean(getToken());
  const user = getUser();
  $('#login').hidden = masuk;
  $('#petunjuk-login').hidden = masuk;
  $('#sesi').hidden = !masuk;
  $('#nama-user').textContent = user ? `${user.nama} (${user.email})` : '';
  if (state.detail) renderDetail(state.detail); // tampilkan / sembunyikan tombol aksi
}

async function kirimLogin(form) {
  const tombol = $('#kirim-login');
  bersihkanError(form);
  sembunyikanAlert();
  tombol.disabled = true;
  try {
    const { email, password } = Object.fromEntries(new FormData(form));
    const { data } = await api.login(email, password);
    simpanSesi({ token: data.token, user: data.user });
    form.reset();
    renderAuth();
  } catch (e) {
    if (e instanceof ApiError && e.status === 422) {
      for (const [field, pesan] of Object.entries(e.errors)) {
        const el = form.querySelector(`[data-error="${field}"]`);
        if (el) el.textContent = pesan[0];
      }
    } else {
      tampilkanAlert(e.message); // 429, 500, offline
    }
  } finally {
    tombol.disabled = false;
  }
}

async function keluar() {
  try {
    await api.logout(); // 204: token dicabut di server
  } catch {
    /* tetap bersihkan sesi lokal */
  }
  hapusSesi();
  renderAuth();
}

// token tersimpan tapi mungkin sudah kedaluwarsa: cek ke server
async function verifikasiSesi() {
  if (!getToken()) return;
  try {
    await api.me();
  } catch {
    /* 401 sudah ditangani onUnauthorized */
  }
}

setOnUnauthorized(() => {
  renderAuth();
  tampilkanAlert('Sesi login berakhir atau belum login. Silakan masuk lagi.');
});

async function muatJenis() {
  const select = $('#jenis');
  try {
    const { data } = await api.jenisSurat();
    select.innerHTML =
      '<option value="">-- Pilih jenis surat --</option>' +
      data
        .map((j) => (typeof j === 'string' ? j : j.nama)) // Node: daftar nama; Laravel: objek jenis surat
        .map((nama) => `<option value="${esc(nama)}">${esc(nama)}</option>`)
        .join('');
  } catch {
    select.innerHTML = '<option value="">(gagal memuat jenis surat)</option>';
  }
}

// ---------- event ----------
let timerCari;
$('#cari').addEventListener('input', (e) => {
  clearTimeout(timerCari); // debounce 400 ms agar tidak memanggil API tiap ketikan
  timerCari = setTimeout(() => {
    state.q = e.target.value.trim();
    state.page = 1;
    muatDaftar();
  }, 400);
});

$('#tabs').addEventListener('click', (e) => {
  const tombol = e.target.closest('[data-status]');
  if (!tombol) return;
  state.status = tombol.dataset.status;
  state.page = 1;
  renderTabs();
  muatDaftar();
});

$('#daftar').addEventListener('click', (e) => {
  const item = e.target.closest('[data-id]');
  if (item) bukaDetail(Number(item.dataset.id));
});

$('#pager').addEventListener('click', (e) => {
  const tombol = e.target.closest('[data-hal]');
  if (!tombol || tombol.disabled) return;
  state.page = Number(tombol.dataset.hal);
  muatDaftar();
});

$('#detail').addEventListener('click', async (e) => {
  const aksi = e.target.closest('[data-aksi]');
  const hapus = e.target.closest('[data-hapus]');

  if (aksi) {
    const catatan = window.prompt('Catatan (opsional):', '');
    if (catatan === null) return;
    await jalankan(async () => {
      const { data } = await api.ubahStatus(state.id, aksi.dataset.aksi, catatan);
      renderDetail(data);
    });
  } else if (hapus) {
    if (!window.confirm('Hapus surat ini?')) return;
    await jalankan(async () => {
      await api.hapusSurat(state.id); // 204 tanpa body
      state.id = null;
      state.detail = null;
      $('#detail').textContent = 'Surat dihapus. Pilih surat lain.';
    });
  }
});

$('#form').addEventListener('submit', (e) => {
  e.preventDefault();
  kirimForm(e.target);
});

$('#login').addEventListener('submit', (e) => {
  e.preventDefault();
  kirimLogin(e.target);
});

$('#keluar').addEventListener('click', keluar);

$('#backend').addEventListener('change', (e) => {
  setBackend(e.target.value); // sesi login terpisah per backend
  Object.assign(state, { status: '', q: '', page: 1, id: null, statistik: null, detail: null });
  $('#cari').value = '';
  $('#detail').textContent = 'Pilih surat di daftar sebelah kiri.';
  bersihkanError($('#form'));
  bersihkanError($('#login'));
  sembunyikanAlert();
  renderAuth();
  muatSemua();
});

function muatSemua() {
  renderTabs();
  return Promise.all([muatJenis(), muatStatistik(), muatDaftar(), verifikasiSesi()]);
}

renderAuth();

muatSemua();
