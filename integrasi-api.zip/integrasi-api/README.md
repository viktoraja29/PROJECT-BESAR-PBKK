# Integrasi API: Pengajuan Surat Mahasiswa

Satu kontrak JSON, dua backend (Laravel dan Node.js/Express), satu frontend `fetch()`.
Berdasarkan materi IFT5251P "API sebagai Integrasi & Format Data".

```
integrasi-api/
├── nodejs/             API Express (:3000) + skrip client tarik-dari-laravel.js
├── laravel-overlay/    kode Laravel (ditimpa ke project Laravel baru)
├── frontend/           HTML + fetch() (index.html, api.js, app.js)
├── docker-compose.yml  Node.js (:3000) + frontend (:8000)
├── setup-laravel.sh/.bat   membuat project Laravel di ./laravel
└── requests.http       uji API dengan ekstensi VS Code "REST Client"
```

## 1. Node.js (butuh Node.js 20+)

```bash
cd nodejs
npm install
npm run dev        # http://localhost:3000/api/v1/surat
```

Variabel opsional: `PORT` (default 3000), `API_KEY` (default `rahasia-demo`).

## 2. Frontend

Buka lewat server (modul ES tidak jalan dari `file://`). Pilih salah satu:

- **Live Server** (ekstensi VS Code): klik kanan `frontend/index.html` > Open with Live Server.
- **Docker**: `docker compose up -d`, lalu buka http://localhost:8000/integrasi-api/frontend/
  (ini juga menjalankan API Node.js, jadi langkah 1 tidak perlu).

Dropdown **Backend** di kanan atas memilih Node.js atau Laravel. Panel **Log Request**
di bawah menampilkan setiap panggilan `fetch()`.

## 3. Laravel (butuh PHP 8.2+ dan Composer)

Folder `laravel-overlay/` hanya berisi file yang ditulis/diganti; project Laravel-nya dibuat oleh skrip:

```bash
./setup-laravel.sh          # Windows: setup-laravel.bat
cd laravel
php artisan serve --port=8001
```

Skrip melakukan `composer create-project`, `php artisan install:api` (memasang Laravel Sanctum),
menyalin overlay, menambah variabel ke `.env` (`API_KEY`, `NOTIFIKASI_URL`, ...), lalu
`php artisan migrate --seed` (SQLite, 5 mahasiswa + 5 surat contoh + 1 akun demo).

File yang ditimpa/ditambah di project Laravel: `bootstrap/app.php`, `config/services.php`,
`routes/api.php`, `lang/en.json`, `database/seeders/DatabaseSeeder.php`, serta
Controller, Request, Resource, Model, Enum, Middleware, Service, factory, migration, seeder.

## Bagian ORM (Pertemuan 9, Eloquent)

Backend Laravel memakai Eloquent ORM; kontrak API ke frontend dan Node.js tidak berubah.

| Konsep materi | Lokasi |
|---|---|
| Migration + foreign key | `database/migrations/2026_11_19_00000*` (mahasiswa, jenis_surat, surat, riwayat_status) |
| Model, `$fillable`, relasi `hasMany`/`belongsTo`, casts, scope | `app/Models/*` |
| Factory + Seeder | `database/factories/MahasiswaFactory.php`, `database/seeders/*` |
| CRUD dengan ORM | `Api/MahasiswaController.php`, `Api/SuratController.php` |
| Eager loading vs N+1 | `with()` di `SuratController@index`; bukti: `php artisan demo:n-plus-1` |
| Transaksi | `Surat::ajukan()` dan `Surat::ubahStatus()` (surat + riwayat dalam satu `DB::transaction`) |

Relasi: Mahasiswa 1..n Surat, JenisSurat 1..n Surat, Surat 1..n RiwayatStatus.
Endpoint tambahan (admin, token): `apiResource('mahasiswa')`, lihat blok M1-M6 di `requests.http`.
Data banyak untuk uji paginasi dan N+1: `php artisan db:seed --class=DataPalsuSeeder`, lalu `php artisan demo:n-plus-1`.

Latihan mandiri modul:

| Latihan | Lokasi |
|---|---|
| 1. CRUD Jenis Surat (hapus yang dipakai -> 409) | `Api/JenisSuratController.php`; `requests.http` J1-J3 |
| 2. Statistik per status dan per jenis surat | `SuratController@statistik`, kunci `per_jenis` (Node.js ikut menyediakan) |
| 3. Tabel dosen + `disetujui_oleh` | migration `..._000005`, `..._000006`, `Models/Dosen.php`, `Surat::disetujuiOleh()`; kirim `dosen_id` pada PATCH status |
| 4. Soft delete (tambahan) | migration `..._000007`, `GET /surat-terhapus`, `POST /surat/{id}/pulihkan` |

Sepuluh skenario checkpoint 8 ada di `requests.http` (blok O1-O10). Draf jawaban laporan ada di `Laporan-ORM.pdf`.
`POST /surat` menerima dua bentuk: `nama/nim/jenis` (frontend) atau `mahasiswa_id/jenis_surat_id` (modul ORM).
`DELETE /surat/{id}` kini soft delete; surat tidak muncul di daftar dan statistik, tetapi bisa dipulihkan.

Catatan: kode Laravel hanya diperiksa sintaksnya (`php -l`), belum dijalankan penuh karena
Composer tidak tersedia di lingkungan penyusunan. Prodi "Teknik Informatika" dan angkatan 2024
pada seeder hanya contoh.

## 4. Mencoba integrasi

- **Webhook Laravel ke Node.js**: jalankan keduanya, ubah status surat lewat frontend (pilih
  Laravel). Terminal Node.js mencetak `[NOTIFIKASI] surat.status_berubah: ...`, dan
  `GET http://localhost:3000/api/v1/notifikasi` menampilkannya.
- **Node.js menarik data Laravel**: `cd nodejs && npm run tarik-laravel`.
- **Uji API**: buka `requests.http` di VS Code (ekstensi REST Client), atau pakai curl:

```bash
curl http://localhost:3000/api/v1/surat/4

# login dulu, lalu pakai token
curl -X POST http://localhost:3000/api/v1/login \
  -H "Content-Type: application/json" \
  -d '{"email":"admin@kampus.test","password":"password"}'

# mengajukan surat: publik, tanpa token
curl -X POST http://localhost:3000/api/v1/surat \
  -H "Content-Type: application/json" \
  -d '{"nama":"","nim":"abc"}'        # -> 422 + errors per field

# memproses surat: khusus admin, pakai token
curl -X PATCH http://localhost:3000/api/v1/surat/6/status \
  -H "Content-Type: application/json" -H "Authorization: Bearer <token>" \
  -d '{"status":"diproses"}'          # -> 200
```

## Data awal (pengirim surat)

| Nama | NIM | Status awal |
|---|---|---|
| Muhammad Farhan | 2443027 | Selesai |
| Muhammad Syahreza | 2443039 | Diproses |
| Shanjay Wijaya Indra Kirana | 2443014 | Ditolak |
| Viktor | 2443085 | Diajukan |
| Julivian Dodi | 2443028 | Diproses |

Mengubah nama atau NIM:
- Node.js: fungsi `seed()` di `nodejs/src/store.js`.
- Laravel: pemanggilan `$this->mahasiswa(...)` di `laravel-overlay/database/seeders/SuratSeeder.php`
  (jalankan ulang `php artisan migrate:fresh --seed` agar tersimpan).

Statistik awal: `{ semua: 5, diajukan: 1, diproses: 2, selesai: 1, ditolak: 1 }`.
Surat baru yang dibuat di latihan mendapat `id` 6.

## Ringkasan API (`/api/v1`)

| Method | Endpoint | Auth | Sukses |
|---|---|---|---|
| POST | `/login` | - | 200 (token) |
| GET | `/me`, POST `/logout` | token | 200 / 204 |
| GET | `/jenis-surat`, `/statistik` | - | 200 |
| GET | `/surat?status=&q=&page=&per_page=` | - | 200 |
| GET | `/surat/{id}` | - | 200 |
| POST | `/surat` | publik (maks 30/menit) | 201 |
| PATCH | `/surat/{id}/status` | admin (token) | 200 |
| DELETE | `/surat/{id}` | admin (token) | 204 |
| POST | `/webhook/status-surat` (Node.js) | X-API-Key | 202 |
| GET | `/notifikasi` (Node.js) | token | 200 |

Error: `401` (token salah), `404`, `429` (terlalu banyak pengajuan), `422` dengan format `{ "message": "...", "errors": { "field": ["..."] } }`.
Alur status: `diajukan -> diproses -> selesai`, dan `diajukan` atau `diproses` dapat `ditolak`.
Selesai dan Ditolak adalah status akhir.

## Status tugas (slide 35)

| # | Tugas | Status |
|---|---|---|
| 1 | curl/Postman: buat, proses, selesaikan | `requests.http` no. 7, 10, 11: **201, 200, 200** |
| 2 | Ubah Selesai ke Diproses | `requests.http` no. 12: **422**, pesan di field `status` |
| 3 | `GET /api/v1/statistik` di kedua backend | selesai |
| 4 | Angka statistik di tab filter, misal "Diajukan (1)" | selesai (`frontend/app.js`) |
| 5 | Simpan notifikasi + `GET /api/v1/notifikasi` | selesai (Node.js) |
| 6 | Login + token (Sanctum) | selesai: `POST /login`, `Authorization: Bearer` (kedua backend + frontend) |

Akun demo: `admin@kampus.test` / `password`. Mahasiswa (publik) boleh mengajukan surat tanpa login; mengubah status dan menghapus surat khusus admin (token).
Jika dosen meminta Selesai boleh kembali ke Diproses, ubah daftar `berikutnya` untuk `selesai` di
`nodejs/src/status.js` dan `laravel-overlay/app/Enums/StatusSurat.php`.

## Catatan

- Data Node.js disimpan di memori: hilang saat server restart.
- Token login disimpan di `sessionStorage` browser (hilang saat tab ditutup). Akun demo dan `X-API-Key: rahasia-demo`
  hanya untuk belajar; ganti sebelum dipakai di luar kelas.
- Penyimpanan token di browser rentan jika ada celah XSS; itu sebabnya semua data dari API di-escape sebelum masuk HTML.
- CORS: Express memakai `cors()`. Laravel 11+ sudah mengizinkan semua origin untuk `api/*` secara bawaan.
